package org.unibl.etf.projekat_bp.entity;

public class Kasa {
    private int IdKasa;

    public Kasa(int idKase) {
        this.IdKasa = idKase;
    }

    public int getIdKasa() {
        return IdKasa;
    }

    public void setIdKasa(int IdKasa) {
        this.IdKasa = IdKasa;
    }
}
