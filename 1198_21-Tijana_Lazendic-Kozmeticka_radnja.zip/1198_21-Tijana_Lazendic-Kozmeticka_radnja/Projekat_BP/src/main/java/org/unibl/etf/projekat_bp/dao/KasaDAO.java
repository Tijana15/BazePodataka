package org.unibl.etf.projekat_bp.dao;


import org.unibl.etf.projekat_bp.entity.Kasa;

import java.util.List;

public interface KasaDAO {
    public List<Kasa> selectAll();

}
