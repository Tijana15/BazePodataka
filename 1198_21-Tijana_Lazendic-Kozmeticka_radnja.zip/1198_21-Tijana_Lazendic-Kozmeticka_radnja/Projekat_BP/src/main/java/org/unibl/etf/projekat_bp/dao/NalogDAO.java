package org.unibl.etf.projekat_bp.dao;

import org.unibl.etf.projekat_bp.entity.Nalog;

import java.util.List;

public interface NalogDAO {
    public List<Nalog> selectAll();
}
