package org.unibl.etf.projekat_bp.dao;

import org.unibl.etf.projekat_bp.entity.StavkaRacun;

public interface StavkaRacunDAO {
    public int insert(StavkaRacun stavkaRacun);
}
